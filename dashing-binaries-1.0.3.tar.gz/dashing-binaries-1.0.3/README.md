
This repository contains binary releases for Dashing1 by version and OS (linux and OSX). For binaries for Dashing2, see [dashing2-binaries](https://github.com/dnbaker/dashing2-binaries).

You can get the latest in the `main` branch or access a specific version with tags.
